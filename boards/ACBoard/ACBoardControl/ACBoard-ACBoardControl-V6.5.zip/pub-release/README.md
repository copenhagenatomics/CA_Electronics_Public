# AC Board - Control

This board is one of two, that need to be connected to get the intended functionality, the other board is 'AC Board - Switching'. The two PCBA's combined can be used to switch AC loads, commonly used for resistive heating elements being controlled with mains power. The boards are stacked using headers and 2mm standoffs, additionally, a heatsink is required for full functionality.

This specific board contains MCU for taking readings and controlling the state of the attached loads, as well as the temperature of the triacs.

### Key features
*  STM32F401x MCU is used to control and measure the current.
    * Read and write access to the board is facilitated via. an USB-C connector.
* The MCU and power side is galvanically isolated with approx. 2.5mm between the copper, standoffs and board spacing.
* Mains voltage can be detected using optocoupler feedback.

### Specification

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Quiescent current                       |    typ.   |  0.3  |    A    |