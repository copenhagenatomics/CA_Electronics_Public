# AC Board - Switching

This board is one of two, that need to be connected to get the intended functionality, the other board is 'AC Board - Control'. The two PCBA's combined can be used to switch AC loads, commonly used for resistive heating elements being controlled with mains power. The boards are stacked using headers and 2mm standoffs, additionally, a heatsink is required for full functionality.

This specific board contains triacs, current measurements and related circuitry.

### Key features
* Four ports individually controlled via a triac and feedback via a hall effect sensor.
* Anti-shock connectors from Phoenix Connectors.
* ~2.5kV isolation between mains and MCU side.
* Good cooling performance through full backplate heatsink.

### Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| AC Mains RMS                                |    min.   |   120 |    V    |
|                                             |    typ.   |   230 |    V    |