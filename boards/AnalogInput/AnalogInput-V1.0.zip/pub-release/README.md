# AnalogInput board

The AnalogInput board's intended functionality is to power and measure from analog sensors using both voltage and current outputs. However, the board also contains generalised features, such as GPIOs and an I2C interface. This board was previously known as the "PressureBoard" but was renamed following an expansion of functionality. AnalogInput is an evolution of the older Pressure board (transferred at Pressure V3.6)

### Key features:

* The board is powered and communicated with using a USB-C interface.
* 6 generic pins in a (DNP) 2.54mm pinheader and one I2C interface pinned out seperatedly.
* Made to fit in standard Copenhagen Atomics size 112x38mm with 1mm corner round.
* Boost converter to have a 28 V rail onboard - expected maximum power consumption 3.8 W
* The board has six ports for supplying power to and measuring from analog sensors, each port has the same features:
    * Supplies 5 - 24 V to sensors, bucked from the 28V rail. Supplies 5V by default (SW controlled)
    * Measures nominally voltage, but can also be switched to measure 4-20mA.
        * Voltage range is configurable - can measure from 0 to anywhere up to the supply voltage
    * High impedance input for voltage mode.
    * Input is filtered with ~1600 Hz low pass filter.


### Specification:

| Parameter                                   | Condition | Value       | Unit(s) |
|---------------------------------------------|:---------:|:-----------:|:-------:|
| USB Voltage                                 |    typ.   |   5         |    V    |
| USB Quiescent current                       |    typ.   |  0.1        |    A    |
| Port output voltage                         |    min.   |  5.05       |    V    |
|                                             |    max.   |  24.05      |    V    |
| Voltage mode input range                    |    nom.   |  0.01-24.00 |    V    |
| Voltage mode input impedance                |    typ.   |  1          |    GΩ   |
| Current mode input range                    |    nom.   |  0-20       |    mA   |
