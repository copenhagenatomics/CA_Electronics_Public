# Current board

The intended functionality of the current board is to measure current from CT coils, this value can be used to find the full scale current, e.g. in a pump. Additionally, the current board has a fault reading, meant to detect shorts in Copenhagen Atomic A/S brand high temperature pumps.

### Key features:
* Three ports which has 3 inputs:
    * Each input port measure current from a current transformer.
    * Measurement is internally biased, so full waveform can be measured.
    * Using the measurement a RMS current is calculated.
* Single output channel, that outputs a current limited 24V voltage, to probe for shorts in the Copenhagen Atomics A/S high temperature pump.
* STM32F401x MCU is used to measure current, calculate rms and communication through USB-C connector.
* Board is galvanically isolated on the USB-C line, as this is needed for correct fault current functionality.
* Board conforms to standard 112x38mm Copenhagen Atomics size.

### Specification:
| Parameter                                         | Condition | Value | Unit(s) |
|---------------------------------------------------|:---------:|:-----:|:-------:|
| Auxiliary input voltage                           |    typ.   |   24  |    V    |
| Auxiliary input current                           |    max.   |   100 |    mA   |
| USB input voltage                                 |    typ.   |   5   |    V    |
| USB input current                                 |    max.   |   150 |    mA   |