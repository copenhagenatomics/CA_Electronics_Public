# DC Board - Specification

The intended functionality of the DC board is to switch (small) DC loads.

### Key features:
* Has six ports for switching DC voltage, each port has the same features:
    * Individually fused.
    * Controlled using a high-side p-channel MOSFET.
    * 24V ESD protection.
    * Freewheeling diode for inductive loads.
    * Current can be measured full range using an halleffect sensor.
    * Can be PWM'd at a few kHz, specific speed depends on the attached load.
* STM32F401x MCU is used to control and measure the current.
    * Read and write access to the board is facilitated via. an USB-C connector.
* The MCU and power side is galvanically isolated with approx. 2.5mm between the copper pours.
* Input DC voltage can be measured optocoupler feedback.
* Reverse voltage protection on the DC voltage input. 
* Made to fit in standard Copenhagen Atomics size 112x38mm with 1mm corner round.

### Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| DC input voltage                            |    min.   |   12  |    V    |
|                                             |    typ.   |   24  |    V    |
| DC Port current                             |    typ.   |   4   |    A    |
| DC Port fuse current                        |    max.   |   5   |    A    |
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Quiescent current                       |    typ.   |  0.3  |    A    |
