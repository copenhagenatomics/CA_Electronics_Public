# 88E1510 Daughterboard

The 88E1510 Daughterboard is intended to be used in place of the RTL8367S on the DataDiode V1.0. See that project for further details.
