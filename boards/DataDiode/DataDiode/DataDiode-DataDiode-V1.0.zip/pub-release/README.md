# DataDiode

The DataDiode is intended to be used as a unidirectional galvanically isolated network link. Data is transmitted optically from Side A ("Anode") to Side B ("Cathode") and with no electrical connectivity on any data, power or ground nets. It is not possible to reverse the data flow in the diode. This first prototype can be used in Ethernet -> Ethernet or USB -> Ethernet configuration. Note: The design did not pass testing in the original form. A daughterboard for a Marvell 88E1510 was designed to take the place of the RTL8367S chip, which enabled use of the unidirectional RGMII interface. The board must be powered via 2 USB-C connectors (one for either side of the galvanic break).

Key features:
* Ethernet -> Ethernet, Up to 1 Gbps via Fibre Optic link (failed testing)
* USB 2 -> Ethernet, Up to 1 Gbps (non-galvanically isolated) (requires 88E1510 daughterboard)
* USB 2 -> Ethernet, Up to 10 Mbps (galvanically isolated) (requires 88E1510 daughterboard)

Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Current                                 |    max.   |   1   |    A    |
| USB Communications Standard                 |           |  2.0  |         |
| USB Communications speed                    |           |  480  |   MHz   |
| Ethernet Communications Speed               |    max.*  |   1   |   Gbps  |

\* Dependent on configuration, see Key features.