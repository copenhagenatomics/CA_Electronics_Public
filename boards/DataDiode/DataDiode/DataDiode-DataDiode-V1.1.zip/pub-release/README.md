# DataDiode

The DataDiode is intended to be used as a unidirectional galvanically isolated network link. Data is transmitted optically from Side A ("Anode") to Side B ("Cathode") and with no electrical connectivity on any data, power or ground nets. It is not possible to reverse the data flow in the diode. This second prototype can be used in USB -> Ethernet or USB -> USB configuration. The board must be powered via 2 USB-C connectors (one for either side of the galvanic break).

Note: The design did not pass testing in the original form:
* The via underneath the text Y2 must be removed to prevent a short of 3V3 to GND. 
* The input to the TX_CLK optocoupler must be inverted to match the other optocouplers.

Key features:
* USB 2 -> Ethernet, Up to 100 Mbps
* USB 2 -> USB 2, Up to 100 Mbps

Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Current                                 |    max.   |  500  |   mA    |
| USB Communications Standard                 |           |  2.0  |         |
| USB Communications speed                    |           |  480  |   MHz   |
| Ethernet Communications Speed               |    max.   |  100  |   Mbps  |
