# DataDiode

The DataDiode is intended to be used as a unidirectional galvanically isolated network link. Data is transmitted optically from Side A ("Anode") to Side B ("Cathode") and with no electrical connectivity on any data, power or ground nets. It is not possible to reverse the data flow in the diode. The ports are USB C -> USB C; both ports must be plugged in in order to power both sides of the diode.

Key features:
* USB 2 -> USB 2, Up to 100 Mbps

Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Current                                 |    max.   |  500  |   mA    |
| USB Communications Standard                 |           |  2.0  |         |
| USB Communications speed                    |           |  480  |   MHz   |
