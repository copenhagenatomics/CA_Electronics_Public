# Flow chip

This is a dual purpose board, that has for historic reasons been named flow chip. A more fitting name could be 'air-conditioning controller' or 'gas flow sensor interface'.

The board has two interfaces, a simple connection for an IR-diode, which can be used to emulate an IR remote. 
The other functionality is an interface that can be soldered onto the Honeywell HAF gas flow sensor family. 
The board uses I2C to communicate with the HAF sensor, and is meant to be directly soldered to the HAF sensor.

### Specification

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Quiescent current                       |    typ.   |  0.25 |    A    |
| I2C voltage                                 |    typ.   |  3.3  |    V    |