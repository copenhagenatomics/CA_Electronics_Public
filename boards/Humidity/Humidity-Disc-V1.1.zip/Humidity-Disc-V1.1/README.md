# Humidity disc.

This board is purely for keeping the main PCBA in place, while it is being potted in place. This is also why there is less files in this zip.