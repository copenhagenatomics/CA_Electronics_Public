# Humidity - Specification

The intended functionality of the humidity board is to measure humidity and temperature using two seperate sensors. Additionally, the board is shaped to allow it to be potted into a 10mm tube, so that the sensors can be installed in a gas system.

### Key features:
* Has two individual SHT45 sensors:
    * Measures humidity 0-100%, check the datasheet for details on this.
    * Measures temperature 0-85°C.
    * Communicates to the STM32F401x using I2C.
* STM32F401x MCU is used to gather data, process and send it on through USB-C.
* Board shape is meant to slot together with the 'humidity-disc' board, and be potted into a 10mm tube.

### Specification:
| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB input voltage                           |    typ.   |   5   |    V    |
| USB input current                           |    max.   |   50  |    mA   |