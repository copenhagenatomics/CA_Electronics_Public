# Humidity sensor

The humidity sensor has two SHT45-AD1F-R2 sensors, which sense relative humidity and temperature. From relative humidity and temperature the absolute humidity can be calculated. However, it should be noted that many factors can influence the measurement, such as contaminents, pressure and other environmental factors.

### Key features:

* The board is powered and communicated with using a USB-C interface.
* Made to fit in a (custom) G1/4 BSPS tube using an o-ring and more to ensure gas tightness in the tube.
* Connects to two SHT45-AD1F-R2 sensors via. I2C.


### Specification:

| Parameter                                   | Condition | Value       | Unit(s) |
|---------------------------------------------|:---------:|:-----------:|:-------:|
| USB Voltage                                 |    typ.   |   5         |    V    |
| USB Quiescent current                       |    typ.   |  0.1        |    A    |
| Relative humidity range                     |    typ.   |  0 to 100   |    %    |
| Relative humidity accuracy                  |    typ.   |  +/-1.0     |    %    |
| Temperature range                           |    typ.   | -40 to +125 |    °C   |
| Temperature accuracy                        |    typ.   |  +/-0.1     |    °C   | 
| Temperature resolution                      |    -      |  0.01       |    °C   |