# Light controller

The intended functionality of the light controller is to switch standard RGBW LED strips. The board has three ports with can be individually controlled.

### Key features:
* Three ports which has 5 outputs:
    * (Typically) 24V output and 4 pins controlled via lowside MOSFET.
* STM32F401x MCU is used to control the output pins, input power and communication through USB-C connector.
* Board conforms to standard 112x38mm Copenhagen Atomics size.

### Specification:
| Parameter                                         | Condition | Value | Unit(s) |
|---------------------------------------------------|:---------:|:-----:|:-------:|
| Auxiliary input voltage                           |    typ.   |   24  |    V    |
| Auxiliary input current (depends on RGBW strip)   |    max.   |   6   |    A    |
| USB input voltage                                 |    typ.   |   5   |    V    |
| USB input current                                 |    max.   |   100 |    mA   |