# Light controller - Specification

The intended functionality of the light controller board is to switch (small) DC loads, namely (24V) RGBW LED strips.

### Key features:
* Has three channels with 5 pins: 24V, R, G, B, W. The RGBW pins are low side switched.
    * 24V pin is fused with 6 A / 82 A^2*sec
* STM32F401x MCU is used to control.
    * Read and write access to the board is facilitated via. an USB-C connector.
* The MCU and power side is galvanically isolated with approx. 2.5mm between the copper pours.
* Input DC voltage can be measured optocoupler feedback.
* Reverse voltage protection on the DC voltage input. 
* Made to fit in standard Copenhagen Atomics size 112x38mm with 1mm corner round.

### Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| DC input voltage                            |    min.   |   12  |    V    |
|                                             |    typ.   |   24  |    V    |
| RGBW Pin current                            |    typ.   |   2   |    A    |
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Quiescent current                       |    typ.   |  0.3  |    A    |
