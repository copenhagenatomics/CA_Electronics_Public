# Phase monitor

This board is for monitoring three phase voltage. It gives a good indication for the state of the voltage, but for accurate voltage levels calibration is necessary.

### Key features
*  STM32F401x MCU is used to control and measure the current.
    * Read and write access to the board is facilitated via. an USB-C connector.
* Takes three phase, neutral and protective earth.
* Each phase is fused with a 250mA fuse.
* ~2.5kV isolation between mains and MCU side.

### Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Quiescent current                       |    typ.   |  0.3  |    A    |
| AC Mains RMS                                |    min.   |   120 |    V    |
|                                             |    typ.   |   230 |    V    |