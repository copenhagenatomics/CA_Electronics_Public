# PiHub / Uploader

The PiHub / Uploader are intended to be used as simple networked controllers for a variety of USB devices.

Key features:
* Carrier for Raspberry Pi Compute Module (4 and onwards)
* Implements 7 port USB 2.0 hub with USB-C connectors
* Implements 2 port networking
* Independent SMPS for USB devices and PiHub
* USB devices are overcurrent protected with a limit
* USB devices can be powered down from software on the Compute Module
* 1 Open/Closed isolated GPIO input
* 1 Open/Closed isolated GPIO output
* (Uploader only) WiFi is enabled on the Compute Module
* External realtime clock
* 1 Open/Closed input for e.g. user input button

Specification:

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| DC input voltage                            |    min.   |   12  |    V    |
|                                             |    typ.   |   24  |    V    |
| USB Voltage                                 |    typ.   |   5   |    V    |
| USB Source Current                          |    max.   |   1   |    A    |
| Simultaneous USB Source Current (All ports) |    max.   |   7   |    A    |
| USB Communications Standard                 |           |  2.0  |         |
| USB Communications speed                    |           |  480  |   MHz   |
| Ethernet Communications Speed               |    max.   |   1   |   Gbps  |