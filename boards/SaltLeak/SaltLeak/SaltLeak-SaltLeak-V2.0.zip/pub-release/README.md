# Saltleak Board

The Saltleak board is intended to be used with 4-wire probes to detect the presence of molten salt.

### Key Features:

* 6x 48V salt resistance measurement channel
* Can measure resistance up to ~100 M&Omega;
* USB Isolated
* Broken wire detection

### Specification

| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|-----------|-------|---------|
| USB Voltage                                 | typ.      | 5     | V       |
| USB Sink Current                            | max.      | 0.2   | A       |
| USB Communications speed                    |           | 12    | MHz     |
| Probe Voltage                               | typ.      | 38    | V       |
| Isolation Voltage                           | cont.     | 500   | V       |
