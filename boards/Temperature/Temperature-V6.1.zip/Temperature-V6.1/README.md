# Temperature

The intended functionality of the temperature board is to take thermocuple measurements, typically type-k, but the board is compatible with most types. The temperature readings are done with a 20 bit chip using SPI.

### Key features:
* Has 10 ports that can each measure a thermocouple:
    * Every second port is using the same 20bit measurement chip.
    * Cold junction compensation built into measurement chip.
* STM32F401x MCU is used to gather data, process, communication through a USB-C connector.
* Board is galvanically isolated on the USB-C line, to provide extra layer of protection from mains shorts to thermocouples.
* Board conforms to standard 112x38mm Copenhagen Atomics size.

### Specification:
| Parameter                                   | Condition | Value | Unit(s) |
|---------------------------------------------|:---------:|:-----:|:-------:|
| USB input voltage                           |    typ.   |   5   |    V    |
| USB input current                           |    max.   |   100 |    mA   |